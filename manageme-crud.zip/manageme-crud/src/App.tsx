import { useState } from "react";
import { User } from "./models/UserModel";
import ProjectPanel from "./components/ProjectPanel";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import "./App.css";
import { selectUser } from "./utils/userUtils";

function App() {
  const [user, setUser] = useState<User | null>(null);

  function onSelectUser(user: User) {
    setUser(user);
    selectUser(user);
  }
  
  return (
    <Container maxWidth={false} disableGutters>
      <>
        <CssBaseline />
        <Box
          sx={{
            bgcolor: "#ebecee",
            width: "100%",
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
            padding: "2rem",
          }}
        >
          {!user && (
            <>
              <h1 style={{ fontSize: "4rem" }}>Select User</h1>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "1rem",
                  marginTop: "1rem",
                }}
              >
                <Box
                  sx={{
                    padding: "10rem",
                    bgcolor: "#fff",
                    cursor: "pointer",
                    fontSize: "3.2rem",
                  }}
                  onClick={() =>
                    onSelectUser({
                      id: 1,
                      name: "JohnDoe",
                      role: "admin",
                    })
                  }
                >
                  Admin
                </Box>
                <Box
                  sx={{
                    padding: "10rem",
                    bgcolor: "#fff",
                    cursor: "pointer",
                    fontSize: "3.2rem",
                  }}
                  onClick={() =>
                    onSelectUser({
                      id: 2,
                      name: "JohnDoe2",
                      role: "devops",
                    })
                  }
                >
                  Devops
                </Box>
                <Box
                  sx={{
                    padding: "10rem",
                    bgcolor: "#fff",
                    cursor: "pointer",
                    fontSize: "3.2rem",
                  }}
                  onClick={() =>
                    onSelectUser({
                      id: 3,
                      name: "JohnDoe3",
                      role: "developer",
                    })
                  }
                >
                  Developer
                </Box>
              </Box>
            </>
          )}

          {user && <ProjectPanel user={user} />}
        </Box>
      </>
    </Container>
  );
}

export default App;
