import { useState, ChangeEvent } from "react";
import { Project } from "../models/ProjectModel";
import { FormControl, TextField, Button } from "@mui/material";

type Props = {
  onSave(project: Project): void;
  currentProject: Project;
};

export default function ProjectEditForm({ currentProject, onSave }: Props) {
  const [name, setName] = useState<string>(currentProject.name || "");

  return (
    <FormControl
      sx={{
        display: "flex",
        gap: "1rem",
        width: "100%",
        bgcolor: "#fff",
        margin: "2rem 0",
        borderRadius: ".6rem",
        padding: "2rem",
      }}
    >
      <h2>Edit project</h2>
      <p>ID: {currentProject.id}</p>
      <TextField
        type="text"
        placeholder="Name"
        value={name}
        inputProps={{ style: { fontSize: 15 } }}
        onChange={(e: ChangeEvent<HTMLInputElement>) => {
          setName(e.target.value);
        }}
      />
      <Button
        variant="text"
        sx={{ fontSize: "1.6rem" }}
        onClick={() => onSave({ ...currentProject, name: name })}
      >
        Save
      </Button>
    </FormControl>
  );
}
