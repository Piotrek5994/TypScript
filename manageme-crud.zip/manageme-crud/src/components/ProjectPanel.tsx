import { useEffect, useState } from "react";
import { User } from "../models/UserModel";
import { Box } from "@mui/material";
import ProjectList from "./ProjectList";
import ProjectForm from "./ProjectForm";
import ProjectEditForm from "./ProjectEditForm";
import { Project } from "../models/ProjectModel";
import { Api } from "../api/api";
import SelectedProject from "./SelectedProject";

type Props = {
  user: User;
};

export default function ProjectPanel({ user }: Props) {
  const api = new Api();
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);

  function onSelectProject(project: Project) {
    setCurrentProject(project);
  }

  function onCloseProject() {
    setCurrentProject(null);
  }

  function onAddProject(project: Project) {
    api.save("project", project);
    setProjects(api.getAll("project") || []);
  }

  function onEditProject(project: Project) {
    setIsEditing(true);
    setProjectToEdit(project);
  }

  function onSaveProject(project: Project) {
    setProjects((prevProjects) => {
      if (prevProjects !== null) {
        const updatedProjects = prevProjects.map((prevProject) => {
          if (prevProject.id === project.id) {
            return project;
          }
          return prevProject;
        });
        api.update("project", updatedProjects);
        return updatedProjects;
      } else {
        return null;
      }
    });

    setIsEditing(false);
  }

  function onDeleteProject(projectId: number) {
    api.delete(projectId, "project");
    setProjects(api.getAll("project") || []);
  }

  useEffect(() => {
    setProjects(api.getAll("project") || []);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Box sx={{ width: "80%" }}>
      <h1 style={{ fontSize: "4rem" }}>
        {" "}
        Welcome back {user.name}! ({user.role})
      </h1>
      {!isEditing && <ProjectForm onAddProject={onAddProject} />}
      {isEditing && projectToEdit && (
        <ProjectEditForm
          onSave={onSaveProject}
          currentProject={projectToEdit}
        />
      )}
      {currentProject && (
        <SelectedProject onClose={onCloseProject} project={currentProject} />
      )}
      <ProjectList
        projects={projects}
        onSelect={onSelectProject}
        onDelete={onDeleteProject}
        onEdit={onEditProject}
      />
    </Box>
  );
}
