import { useState } from "react";
import {
  TextField,
  Button,
  Radio,
  RadioGroup,
  FormControl,
  FormControlLabel,
  Dialog,
  Select,
  MenuItem,
  InputLabel,
} from "@mui/material";
import { Task } from "../models/TaskModel";
import { Api } from "../api/api";
import { users } from "../utils/userUtils";

type Props = {
  renderTasks(storyId: number): void;
  open: boolean;
  onClose(): void;
  storyId: number;
};

export default function AddTaskModal({
  renderTasks,
  storyId,
  open,
  onClose,
}: Props) {
  const api = new Api();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("low");
  const [predictedTime, setPredictedTime] = useState("");
  const [selectedUser, setSelectedUser] = useState<number | undefined>(
    undefined
  );

  function handleSave() {
    const status = selectedUser ? "Doing" : "Todo";
    const currentDate = selectedUser ? new Date() : undefined;
    const newTask = new Task(
      name,
      description,
      priority as "low" | "medium" | "high",
      storyId,
      parseInt(predictedTime),
      status,
      selectedUser || undefined,
      new Date(),
      currentDate
    );
    api.save("task", newTask);

    renderTasks(storyId);
    onClose();
  }

  return (
    <Dialog open={open} onClose={onClose}>
      <FormControl
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: "1rem",
          width: "100%",
          bgcolor: "#fff",
          margin: "2rem 0",
          borderRadius: ".6rem",
          padding: "1rem",
        }}
      >
        <TextField
          label="Name"
          type="text"
          name="name"
          value={name}
          inputProps={{ style: { fontSize: 15 } }}
          onChange={(e) => setName(e.target.value)}
        />
        <TextField
          label="Description"
          type="text"
          name="description"
          value={description}
          inputProps={{ style: { fontSize: 15 } }}
          onChange={(e) => setDescription(e.target.value)}
        />
        <RadioGroup
          aria-label="priority"
          name="priority"
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
        >
          <FormControlLabel
            value="low"
            control={<Radio />}
            label="Low"
            sx={{ fontSize: 16 }}
          />
          <FormControlLabel
            value="medium"
            control={<Radio />}
            label="Medium"
            sx={{ fontSize: 16 }}
          />
          <FormControlLabel
            value="high"
            control={<Radio />}
            label="High"
            sx={{ fontSize: 16 }}
          />
        </RadioGroup>

        <TextField
          label="Predicted Time"
          fullWidth
          type="number"
          value={predictedTime}
          onChange={(e) => setPredictedTime(e.target.value)}
          inputProps={{ style: { fontSize: 15 } }}
        />

        <FormControl>
          <InputLabel id="user-select-label">Select User</InputLabel>
          <Select
            labelId="user-select-label"
            label="Select User"
            id="user-select"
            value={selectedUser}
            onChange={(e) => setSelectedUser(Number(e.target.value))}
            inputProps={{ style: { fontSize: 15 } }}
          >
            <MenuItem value={undefined}>None</MenuItem>
            {users.map((user) => (
              <MenuItem key={user.id} value={user.id}>
                {user.name} ({user.role})
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <Button
          variant="outlined"
          onClick={handleSave}
          sx={{ mt: 2, fontSize: 16 }}
        >
          Save
        </Button>
      </FormControl>
    </Dialog>
  );
}
