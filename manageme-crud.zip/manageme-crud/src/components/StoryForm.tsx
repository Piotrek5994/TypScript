import { FormControl, TextField, Button } from "@mui/material";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormLabel from "@mui/material/FormLabel";
import { Story } from "../models/StoryModel";
import { useState } from "react";
import { getUser } from "../utils/userUtils";

type Props = {
  onAddStory(story: Story): void;
  projectId: number;
};

export default function StoryForm({ projectId, onAddStory }: Props) {
  const [storyData, setStoryData] = useState({
    name: "",
    description: "",
    priority: "Low",
    state: "Todo",
  });

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setStoryData((prevStoryData) => ({
      ...prevStoryData,
      [name]: value,
    }));
  };

  const handlePriorityChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setStoryData((prevStoryData) => ({
      ...prevStoryData,
      priority: event.target.value,
    }));
  };
  
  const handleAddStory = () => {
    onAddStory({
      id: Date.now(),
      name: storyData.name,
      description: storyData.description,
      priority: storyData.priority as "low" | "medium" | "high",
      project: projectId,
      creationDate: new Date(),
      state: storyData.state as "todo" | "doing" | "done",
      ownerId: getUser()?.id || 1,
    });

    setStoryData({
      name: "",
      description: "",
      priority: "Low",
      state: "Todo",
    });
  };

  return (
    <FormControl
      sx={{
        display: "flex",
        gap: "1rem",
        width: "100%",
        bgcolor: "#fff",
        margin: "2rem 0",
        borderRadius: ".6rem",
        padding: "1rem",
      }}
    >
      <h2>Add new story</h2>
      <TextField
        type="text"
        placeholder="Name"
        name="name"
        value={storyData.name}
        inputProps={{ style: { fontSize: 15 } }}
        onChange={handleInputChange}
      />
      <TextField
        type="text"
        placeholder="Description"
        name="description"
        value={storyData.description}
        inputProps={{ style: { fontSize: 15 } }}
        onChange={handleInputChange}
      />
      <FormLabel id="priority" sx={{ fontSize: "1.6rem" }}>
        Priority
      </FormLabel>
      <RadioGroup
        aria-labelledby="priority"
        value={storyData.priority}
        name="priority"
        onChange={handlePriorityChange}
      >
        <FormControlLabel value="Low" control={<Radio />} label="Low" />
        <FormControlLabel value="Medium" control={<Radio />} label="Medium" />
        <FormControlLabel value="High" control={<Radio />} label="High" />
      </RadioGroup>

      <Button
        variant="text"
        sx={{ fontSize: "1.6rem" }}
        onClick={handleAddStory}
      >
        Add story
      </Button>
    </FormControl>
  );
}
