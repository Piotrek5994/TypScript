// import {
//   FormControl,
//   TextField,
//   Button,
//   Select,
//   MenuItem,
//   InputLabel,
// } from "@mui/material";
// import Radio from "@mui/material/Radio";
// import RadioGroup from "@mui/material/RadioGroup";
// import FormControlLabel from "@mui/material/FormControlLabel";
// import FormLabel from "@mui/material/FormLabel";
// import { Story } from "../models/StoryModel";
// import { useState } from "react";

// type Props = {
//   projectId: number;
//   stories: Story[];
//   onUpdateStory(story: Story): void;
// };

// export default function UpdateStoryForm({
//   projectId,
//   stories,
//   onUpdateStory,
// }: Props) {
//   const [storyData, setStoryData] = useState({
//     name: "",
//     description: "",
//     priority: "Low",
//     state: "Todo",
//   });

//   const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     const { name, value } = event.target;
//     setStoryData((prevStoryData) => ({
//       ...prevStoryData,
//       [name]: value,
//     }));
//   };

//   const handlePriorityChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setStoryData((prevStoryData) => ({
//       ...prevStoryData,
//       priority: event.target.value,
//     }));
//   };

//   const handleStateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setStoryData((prevStoryData) => ({
//       ...prevStoryData,
//       state: event.target.value,
//     }));
//   };

//   const handleSelectChange = (event: React.ChangeEvent<{ value: unknown }>) => {
//     if (stories) {
//       const selectedStoryId = event.target.value as number;
//       const selectedStory = stories.find(
//         (story) => story.id === selectedStoryId
//       );
//       if (selectedStory) {
//         setStoryData({
//           name: selectedStory.name,
//           description: selectedStory.description,
//           priority: selectedStory.priority,
//           state: selectedStory.state,
//         });
//       }
//     }
//   };

//   const handleUpdateStory = () => {
//     if (storyData) {
//       const updatedStory = {
//         ...storyData,
//         priority: storyData.priority as "low" | "medium" | "high",
//         state: storyData.state as "todo" | "doing" | "done",
//         project: projectId,
//         creationDate: new Date(),
//         ownerId: 1,
//       };
      
//       onUpdateStory(updatedStory);
//     }
//   };

//   return (
//     <FormControl
//       sx={{
//         display: "flex",
//         gap: "1rem",
//         width: "100%",
//         bgcolor: "#fff",
//         margin: "2rem 0",
//         borderRadius: ".6rem",
//         padding: "1rem",
//       }}
//     >
//       <h2>Update story</h2>
//       <InputLabel id="select-story-label">Select Story to Edit</InputLabel>
//       <Select
//         labelId="select-story-label"
//         id="select-story"
//         value={storyData.id || ""}
//         onChange={handleSelectChange}
//         displayEmpty
//       >
//         <MenuItem value="" disabled>
//           Select a story
//         </MenuItem>
//         {stories.map((story) => (
//           <MenuItem key={story.id} value={story.id}>
//             {story.name}
//           </MenuItem>
//         ))}
//       </Select>
//       <TextField
//         type="text"
//         placeholder="Name"
//         name="name"
//         value={storyData.name}
//         inputProps={{ style: { fontSize: 15 } }}
//         onChange={handleInputChange}
//       />
//       <TextField
//         type="text"
//         placeholder="Description"
//         name="description"
//         value={storyData.description}
//         inputProps={{ style: { fontSize: 15 } }}
//         onChange={handleInputChange}
//       />
//       <FormLabel id="priority" sx={{ fontSize: "1.6rem" }}>
//         Priority
//       </FormLabel>
//       <RadioGroup
//         aria-labelledby="priority"
//         value={storyData.priority}
//         name="priority"
//         onChange={handlePriorityChange}
//       >
//         <FormControlLabel value="Low" control={<Radio />} label="Low" />
//         <FormControlLabel value="Medium" control={<Radio />} label="Medium" />
//         <FormControlLabel value="High" control={<Radio />} label="High" />
//       </RadioGroup>

//       <FormLabel id="state" sx={{ fontSize: "1.6rem" }}>
//         State
//       </FormLabel>
//       <RadioGroup
//         aria-labelledby="state"
//         value={storyData.state}
//         name="state"
//         onChange={handleStateChange}
//       >
//         <FormControlLabel value="Todo" control={<Radio />} label="Todo" />
//         <FormControlLabel value="Doing" control={<Radio />} label="Doing" />
//         <FormControlLabel value="Done" control={<Radio />} label="Done" />
//       </RadioGroup>

//       <Button
//         variant="text"
//         sx={{ fontSize: "1.6rem" }}
//         onClick={handleUpdateStory}
//       >
//         Update story
//       </Button>
//     </FormControl>
//   );
// }
