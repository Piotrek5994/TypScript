import { FormControl, TextField, Button } from "@mui/material";
import { ChangeEvent, useState } from "react";
import { Project } from "../models/ProjectModel";

type Props = {
  onAddProject(project: Project): void;
};

export default function ProjectForm({ onAddProject }: Props) {
  const [name, setName] = useState("");

  function submitHandler() {
    onAddProject({
      id: Date.now(),
      name: name,
    });

    setName("");
  }
  return (
    <FormControl
      sx={{
        display: "flex",
        gap: "1rem",
        width: "100%",
        bgcolor: "#fff",
        margin: "2rem 0",
        borderRadius: ".6rem",
        padding: "2rem",
      }}
    >
      <h2>Add new project</h2>
      <TextField
        type="text"
        placeholder="Name"
        value={name}
        inputProps={{ style: { fontSize: 15 } }}
        onChange={(e: ChangeEvent<HTMLInputElement>) => {
          setName(e.target.value);
        }}
      />
      <Button
        variant="text"
        sx={{ fontSize: "1.6rem" }}
        onClick={submitHandler}
      >
        Add project
      </Button>
    </FormControl>
  );
}
