import React, { useState } from "react";
import {
  FormControl,
  TextField,
  Button,
  Dialog,
  FormLabel,
  FormControlLabel,
  RadioGroup,
  Radio,
} from "@mui/material";
import { Story } from "../models/StoryModel";

type Props = {
  isOpen: boolean;
  currentStory: Story;
  onSave(story: Story): void;
  onClose(): void;
};

export default function StoryModal({
  isOpen,
  currentStory,
  onSave,
  onClose,
}: Props) {
  const [updatedStory, setUpdatedStory] = useState<Story>(currentStory);

  const handleInputChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setUpdatedStory((prevStory) => ({
      ...prevStory,
      [name]: value,
    }));
  };

  const handlePriorityChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setUpdatedStory((prevStory: Story) => ({
      ...prevStory,
      priority: event.target.value as "low" | "medium" | "high",
    }));
  };

  const handleStateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setUpdatedStory((prevStory: Story) => ({
      ...prevStory,
      state: event.target.value as "todo" | "doing" | "done",
    }));
  };

  const handleSubmit = () => {
    onSave(updatedStory);
    onClose();
  };

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <FormControl
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: "1rem",
          width: "100%",
          bgcolor: "#fff",
          margin: "2rem 0",
          borderRadius: ".6rem",
          padding: "1rem",
        }}
      >
        <h2>Update story</h2>
        <TextField
          type="text"
          placeholder="Name"
          name="name"
          value={updatedStory.name}
          inputProps={{ style: { fontSize: 15 } }}
          InputLabelProps={{ style: { fontSize: 15 } }}
          onChange={handleInputChange}
        />
        <TextField
          type="text"
          placeholder="Description"
          name="description"
          value={updatedStory.description}
          inputProps={{ style: { fontSize: 15 } }}
          InputLabelProps={{ style: { fontSize: 15 } }}
          onChange={handleInputChange}
        />
        <FormLabel id="priority" sx={{ fontSize: "1.6rem" }}>
          Priority
        </FormLabel>
        <RadioGroup
          aria-labelledby="priority"
          value={updatedStory.priority}
          name="priority"
          onChange={handlePriorityChange}
        >
          <FormControlLabel value="Low" control={<Radio />} label="Low" />
          <FormControlLabel value="Medium" control={<Radio />} label="Medium" />
          <FormControlLabel value="High" control={<Radio />} label="High" />
        </RadioGroup>

        <FormLabel id="state" sx={{ fontSize: "1.6rem" }}>
          State
        </FormLabel>
        <RadioGroup
          aria-labelledby="state"
          value={updatedStory.state}
          name="state"
          onChange={handleStateChange}
        >
          <FormControlLabel value="Todo" control={<Radio />} label="Todo" />
          <FormControlLabel value="Doing" control={<Radio />} label="Doing" />
          <FormControlLabel value="Done" control={<Radio />} label="Done" />
        </RadioGroup>

        <Button
          variant="text"
          sx={{ fontSize: "1.6rem" }}
          onClick={handleSubmit}
        >
          Update story
        </Button>
      </FormControl>
    </Dialog>
  );
}
