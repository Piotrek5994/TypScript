import { useState, useEffect } from "react";
import { Api } from "../api/api";
import { Project } from "../models/ProjectModel";
import { Story } from "../models/StoryModel";
import {
  Box,
  Button,
  Grid,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import StoryForm from "./StoryForm";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import StoryModal from "./StoryModal";
import { Task } from "../models/TaskModel";
import AddTaskModal from "./AddTaskModal";
import UpdateTaskModal from "./UpdateTaskModal";

type Props = {
  project: Project;
  onClose: () => void;
};

export default function SelectedProject({ project, onClose }: Props) {
  const api = new Api();
  const [stories, setStories] = useState<Story[] | null>(null);
  const [storyModalOpen, setStoryModalOpen] = useState<boolean>(false);
  const [storyId, setStoryId] = useState<number>(-1);
  const [selectedStory, setSelectedStory] = useState<Story>();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task>();
  const [addTaskModalOpen, setAddTaskModalOpen] = useState<boolean>(false);
  const [updateTaskModalOpen, setUpdateTaskModalOpen] =
    useState<boolean>(false);

  function onAddStory(story: Story) {
    api.save("story", story);
    setStories(api.getAll("story") || []);
  }

  function onSaveStory(updatedStory: Story) {
    if (stories) {
      const updatedStories = stories.map((story) =>
        story.id === updatedStory.id ? updatedStory : story
      );

      setStories((prevStories) => {
        if (prevStories !== null) {
          api.update("story", updatedStories);
          return updatedStories;
        } else {
          return null;
        }
      });
    }
  }

  function onDeleteStory(storyId: number) {
    api.delete(storyId, "story");
    setStories(api.getAll("story") || []);
  }

  function renderTasks(storyId: number) {
    setTasks(api.getAll("task") || []);

    const tasksForStory = api
      .getAll<Task>("task")
      .filter((task) => task.story === storyId);

    if (tasksForStory.length > 0) {
      const existingStory = api.get<Story>(storyId, "story");
      existingStory.state = "Doing" as "doing";
      onSaveStory(existingStory);
    }
  }

  function onDeleteTask(taskId: number) {
    const task = api.get<Task>(taskId, "task");
    const story = task.story;

    api.delete(taskId, "task");
    setTasks(api.getAll("task") || []);

    const tasksForStory = api
      .getAll<Task>("task")
      .filter((task) => task.story === story);

    if (tasksForStory.length === 0) {
      const existingStory = api.get<Story>(story, "story");
      existingStory.state = "Todo" as "todo";
      onSaveStory(existingStory);
    }
  }

  function onUpdateTask(updatedTask: Task) {
    if (tasks) {
      const updatedTasks = tasks.map((task) =>
        task.id === updatedTask.id ? updatedTask : task
      );
      setTasks((prevTasks) => {
        if (prevTasks !== null) {
          api.update("task", updatedTasks);
          return updatedTasks;
        } else {
          return null;
        }
      });
    }

    const tasksForStory = api
      .getAll<Task>("task")
      .filter((task) => task.story === updatedTask.story);

    if (
      tasksForStory.length > 0 &&
      tasksForStory.every((t) => t.state === "Done")
    ) {
      const existingStory = api.get<Story>(updatedTask.story, "story");
      existingStory.state = "Done" as "done";
      onSaveStory(existingStory);
    }
  }

  useEffect(() => {
    setStories(api.getAll("story") || []);
    setTasks(api.getAll("task") || []);
  }, []);

  const taskStates = ["Todo", "Doing", "Done"];

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: "1rem",
        width: "100%",
        bgcolor: "#fff",
        margin: "2rem 0",
        borderRadius: ".6rem",
        padding: "2rem",
      }}
    >
      <Button variant="text" sx={{ fontSize: "1.6rem" }} onClick={onClose}>
        Close project
      </Button>
      <h2>
        {project.id} {project.name}
      </h2>

      <h2>Stories:</h2>
      <Box sx={{ fontSize: "1.6rem" }}>
        <ul>
          {stories
            ?.filter((s) => s.project === project.id)
            .map((s) => (
              <Accordion key={s.id}>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography sx={{ fontSize: "1.6rem" }}>
                    {s.name} *{s.state}* {s.id}
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Button
                    sx={{ marginBottom: "1rem" }}
                    variant="outlined"
                    color="error"
                    onClick={() => onDeleteStory(s.id)}
                  >
                    Delete story
                  </Button>
                  <Button
                    sx={{ marginBottom: "1rem", marginLeft: "1rem" }}
                    variant="outlined"
                    color="warning"
                    onClick={() => {
                      setSelectedStory(s);
                      setStoryModalOpen(true);
                    }}
                  >
                    Update Story
                  </Button>
                  <StoryModal
                    onClose={() => setStoryModalOpen(false)}
                    onSave={onSaveStory}
                    currentStory={selectedStory || s}
                    isOpen={selectedStory === s && storyModalOpen}
                  />
                  <Typography sx={{ fontSize: "1.6rem" }}>
                    Description: {s.description}
                  </Typography>
                  <Typography sx={{ fontSize: "1.6rem", marginTop: "1rem" }}>
                    Priority: {s.priority}
                  </Typography>
                  <Typography
                    sx={{
                      fontSize: "1.8rem",
                      marginTop: "1rem",
                      fontWeight: "bolder",
                    }}
                  >
                    Tasks:
                  </Typography>
                  <Grid container spacing={2}>
                    {taskStates.map((state) => (
                      <Grid item xs={4} key={state}>
                        <Box
                          sx={{
                            padding: "1rem",
                            backgroundColor: "#f0f0f0",
                            borderRadius: "8px",
                          }}
                        >
                          <Typography
                            variant="h6"
                            sx={{ marginBottom: "1rem" }}
                          >
                            {state}
                          </Typography>
                          {tasks &&
                            tasks
                              .filter(
                                (t) => t.story === s.id && t.state === state
                              )
                              .map((t) => (
                                <Box
                                  key={t.id}
                                  sx={{
                                    display: "flex",
                                    flexDirection: "column",
                                    marginBottom: "1rem",
                                    padding: "1rem",
                                    backgroundColor: "#fff",
                                    borderRadius: "4px",
                                    boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                                  }}
                                >
                                  <Typography
                                    sx={{ fontSize: "1.6rem", flexGrow: 1 }}
                                  >
                                    <h3>{t.name}</h3>
                                    <p>{t.description}</p>
                                    <p>State: {t.state}</p>
                                    <p>Priority: {t.priority}</p>
                                    <p>
                                      {" "}
                                      {t.startDate
                                        ? `  Start: ${t.startDate
                                            .toString()
                                            .slice(0, 10)}`
                                        : ""}
                                    </p>
                                    <p>
                                      {" "}
                                      {t.finishDate
                                        ? `Finish: ${t.finishDate
                                            .toString()
                                            .slice(0, 10)}`
                                        : ""}
                                    </p>
                                  </Typography>
                                  <Box>
                                    {" "}
                                    <Button
                                      variant="outlined"
                                      color="warning"
                                      onClick={() => {
                                        setSelectedTask(t);
                                        setUpdateTaskModalOpen(true);
                                      }}
                                    >
                                      Update
                                    </Button>
                                    <Button
                                      sx={{ marginLeft: "1rem" }}
                                      variant="outlined"
                                      color="error"
                                      onClick={() => onDeleteTask(t.id)}
                                    >
                                      Delete
                                    </Button>
                                  </Box>

                                  <UpdateTaskModal
                                    onClose={() =>
                                      setUpdateTaskModalOpen(false)
                                    }
                                    onSave={onUpdateTask}
                                    currentTask={selectedTask || t}
                                    isOpen={updateTaskModalOpen}
                                  />
                                </Box>
                              ))}
                          {(!tasks ||
                            tasks.filter(
                              (t) => t.story === s.id && t.state === state
                            ).length === 0) && (
                            <Typography>No tasks in this state</Typography>
                          )}
                        </Box>
                      </Grid>
                    ))}
                  </Grid>
                  <Button
                    sx={{ marginTop: "1rem" }}
                    variant="outlined"
                    onClick={() => {
                      setStoryId(s.id);
                      setAddTaskModalOpen(true);
                    }}
                  >
                    Add new task
                  </Button>
                </AccordionDetails>
              </Accordion>
            ))}
        </ul>
      </Box>
      <AddTaskModal
        renderTasks={renderTasks}
        storyId={storyId}
        open={addTaskModalOpen}
        onClose={() => setAddTaskModalOpen(false)}
      />
      <StoryForm projectId={project.id} onAddStory={onAddStory} />
    </Box>
  );
}
