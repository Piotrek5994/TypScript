import {
  Dialog,
  FormControl,
  TextField,
  Button,
  FormLabel,
  Radio,
  FormControlLabel,
  RadioGroup,
  Select,
  MenuItem,
  InputLabel,
} from "@mui/material";
import { Task } from "../models/TaskModel";
import { useState, useEffect } from "react";
import { users } from "../utils/userUtils";

type Props = {
  onClose(): void;
  onSave(task: Task): void;
  currentTask: Task;
  isOpen: boolean;
};

export default function UpdateTaskModal({
  isOpen,
  currentTask,
  onClose,
  onSave,
}: Props) {
  const [task, setTask] = useState<Task>(currentTask);
  const [selectedUser, setSelectedUser] = useState<number | undefined>(
    currentTask.ownerId
  );

  useEffect(() => {
    setTask(currentTask);
    setSelectedUser(currentTask.ownerId);
  }, [currentTask]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setTask((prevTask) => ({
      ...prevTask,
      [name]: value,
    }));
  };

  const handlePriorityChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTask((prevTask) => ({
      ...prevTask,
      priority: event.target.value as "low" | "medium" | "high",
    }));
  };

  const handleStateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newState = event.target.value as "Todo" | "Doing" | "Done";
    setTask((prevTask) => ({
      ...prevTask,
      state: newState,
      finishDate: newState === "Done" ? new Date() : prevTask.finishDate,
    }));
  };

  const handlePredictedTimeChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { value } = event.target;
    setTask((prevTask) => ({
      ...prevTask,
      predictedTime: +value,
    }));
  };

  function handleSave() {
    onSave(task);
    onClose();
  }

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <FormControl
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: "1rem",
          width: "100%",
          bgcolor: "#fff",
          margin: "2rem 0",
          borderRadius: ".6rem",
          padding: "1rem",
        }}
      >
        <TextField
          type="text"
          placeholder="Name"
          name="name"
          label="Name"
          value={task.name}
          onChange={handleChange}
          inputProps={{ style: { fontSize: 15 } }}
          InputLabelProps={{ style: { fontSize: 15 } }}
        />

        <TextField
          type="text"
          placeholder="Description"
          name="description"
          label="Description"
          value={task.description}
          onChange={handleChange}
          inputProps={{ style: { fontSize: 15 } }}
          InputLabelProps={{ style: { fontSize: 15 } }}
        />

        <FormLabel id="priority" sx={{ fontSize: "1.6rem" }}>
          Priority
        </FormLabel>
        <RadioGroup
          aria-labelledby="priority"
          value={task.priority}
          name="priority"
          onChange={handlePriorityChange}
        >
          <FormControlLabel value="low" control={<Radio />} label="Low" />
          <FormControlLabel value="medium" control={<Radio />} label="Medium" />
          <FormControlLabel value="high" control={<Radio />} label="High" />
        </RadioGroup>

        <FormLabel id="state" sx={{ fontSize: "1.6rem" }}>
          State
        </FormLabel>
        <RadioGroup
          aria-labelledby="state"
          value={task.state}
          name="state"
          onChange={handleStateChange}
        >
          <FormControlLabel value="Todo" control={<Radio />} label="Todo" />
          <FormControlLabel value="Doing" control={<Radio />} label="Doing" />
          <FormControlLabel value="Done" control={<Radio />} label="Done" />
        </RadioGroup>

        <TextField
          type="text"
          placeholder="Predicted Time"
          name="predictedTime"
          label="Predicted Time"
          value={task.predictedTime}
          onChange={handlePredictedTimeChange}
          inputProps={{ style: { fontSize: 15 } }}
          InputLabelProps={{ style: { fontSize: 15 } }}
        />

        <InputLabel id="user-select-label">Select User</InputLabel>
        <Select
          labelId="user-select-label"
          id="user-select"
          value={selectedUser || ""}
          onChange={(e) => setSelectedUser(e.target.value as number)}
          inputProps={{ style: { fontSize: 15 } }}
        >
          <MenuItem value={task.ownerId}>None</MenuItem>
          {users.map((user) => (
            <MenuItem key={user.id} value={user.id}>
              {user.name} ({user.role})
            </MenuItem>
          ))}
        </Select>

        <Button variant="text" sx={{ fontSize: "1.6rem" }} onClick={handleSave}>
          Update task
        </Button>
      </FormControl>
    </Dialog>
  );
}
