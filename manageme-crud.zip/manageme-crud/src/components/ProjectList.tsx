import { Project } from "../models/ProjectModel";
import { Box, IconButton } from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import CheckBoxIcon from "@mui/icons-material/CheckBox";

type Props = {
  projects: Project[] | null;
  onEdit: (project: Project) => void;
  onDelete: (projectId: number) => void;
  onSelect: (project: Project) => void;
};

export default function ProjectList({
  projects,
  onSelect,
  onEdit,
  onDelete,
}: Props) {
  const columns: GridColDef[] = [
    { field: "id", headerName: "ID", width: 200 },
    { field: "name", headerName: "Name", width: 200 },
    {
      field: "actions",
      headerName: "Actions",
      width: 200,
      renderCell: (params) => (
        <>
          <IconButton type="submit" onClick={() => onSelect(params.row)}>
            <CheckBoxIcon />
          </IconButton>
          <IconButton onClick={() => onEdit(params.row)}>
            <EditIcon />
          </IconButton>
          <IconButton onClick={() => onDelete(params.row.id)}>
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ];

  const rows = projects || [];

  return (
    <Box sx={{ width: "100%" }}>
      {projects ? (
        <DataGrid rows={rows} columns={columns} sx={{ fontSize: "1.6em" }} />
      ) : (
        <p>No projects yet!</p>
      )}
    </Box>
  );
}
