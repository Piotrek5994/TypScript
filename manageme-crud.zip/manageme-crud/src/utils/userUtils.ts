import { User } from "../models/UserModel";

export const users: User[] = [
  {
    id: 1,
    name: "JohnDoe",
    role: "admin",
  },
  {
    id: 2,
    name: "JohnDoe2",
    role: "devops",
  },
  {
    id: 3,
    name: "JohnDoe3",
    role: "developer",
  },
];

export const selectUser = (user: User) => {
  const userObj = {
    id: user.id,
    name: user.name,
    role: user.role,
  };
  localStorage.setItem("selectedUser", JSON.stringify(userObj));
};

export const getUser = (): User | null => {
  const user = localStorage.getItem("selectedUser");
  if (user) {
    const parsedUser = JSON.parse(user);
    return new User(parsedUser.id, parsedUser.name, parsedUser.role);
  }
  return null;
};
