import { Project } from "../models/ProjectModel";
import { Story } from "../models/StoryModel";
import { Task } from "../models/TaskModel";

export class Api {
  getAll<T extends Project | Story | Task>(key: string): T[] {
    const dataFromLocalStorage = localStorage.getItem(key);
    return dataFromLocalStorage && JSON.parse(dataFromLocalStorage);
  }

  save<T extends Project | Story | Task>(key: string, item: T): void {
    const allData = this.getAll<T>(key) || [];
    allData.push(item);
    localStorage.setItem(key, JSON.stringify(allData));
  }

  update<T extends Project | Story | Task>(key: string, items: T[]): void {
    localStorage.setItem(key, JSON.stringify(items));
  }

  delete<T extends Project | Story | Task>(id: number, key: string): void {
    const allData = this.getAll<T>(key);
    const filteredData = allData.filter((d) => d.id !== id);
    localStorage.setItem(key, JSON.stringify(filteredData));
  }

  get<T extends Project | Story | Task>(id: number, key: string): T {
    return this.getAll<T>(key).filter((d) => d.id === id)[0];
  }
}
