export class Task {
  id: number;
  name: string;
  description: string;
  priority: "low" | "medium" | "high";
  story: number;
  predictedTime: number;
  state: "Todo" | "Doing" | "Done";
  createDate: Date;
  startDate?: Date | undefined;
  finishDate?: Date | undefined;
  ownerId?: number | undefined;

  constructor(
    name: string,
    description: string,
    priority: "low" | "medium" | "high",
    story: number,
    predictedTime: number,
    state: "Todo" | "Doing" | "Done",
    ownerId: number | undefined,
    createDate: Date,
    startDate?: Date | undefined,
    finishDate?: Date | undefined
  ) {
    this.id = Date.now();
    this.name = name;
    this.description = description;
    this.priority = priority;
    this.story = story;
    this.predictedTime = predictedTime;
    this.state = state;
    this.createDate = createDate;
    this.startDate = startDate;
    this.finishDate = finishDate;
    this.ownerId = ownerId;
  }
}
