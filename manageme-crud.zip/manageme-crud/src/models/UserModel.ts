export class User {
  id: number;
  name: string;
  role: "admin" | "devops" | "developer";

  constructor(id: number, name: string, role: "admin" | "devops") {
    this.id = id;
    this.name = name;
    this.role = role;
  }
}
