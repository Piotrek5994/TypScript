export class Story {
  id: number;
  name: string;
  description: string;
  priority: "low" | "medium" | "high";
  project: number;
  creationDate: Date;
  state: "todo" | "doing" | "done";
  ownerId: number;

  constructor(
    name: string,
    description: string,
    priority: "low" | "medium" | "high",
    project: number,
    ownerId: number
  ) {
    this.id = Date.now();
    this.name = name;
    this.description = description;
    this.priority = priority;
    this.project = project;
    this.creationDate = new Date();
    this.state = "todo";
    this.ownerId = ownerId;
  }
}
